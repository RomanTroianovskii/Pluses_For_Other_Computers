﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pluses
{
    public class Student
    {
        public int pluses { get; set; }
        public List<DateTime> history { get; set; } = new List<DateTime>();
        public int countOfFives { get; set; } = 0;
        public string FIO { get; set; } = "";
        public Student(int pluses, List<DateTime> history, int countOfFives, string FIO)
        {
            this.pluses = pluses;
            this.history = history;
            this.countOfFives = countOfFives;
            this.FIO = FIO;
        }

        public Student() { }
    }
}
