﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;

namespace Pluses
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Class current_class;
        DataTable dataTable = new DataTable();
        List<Class> classes = new List<Class>();

        bool is_start = true;

        bool is_classEntered = false;
        public MainWindow()
        {
            InitializeComponent();
            List<DateTime> History = new List<DateTime>
            {
                DateTime.Now
            };
            TableSet("data.xml");
            Add.AddStudent += AddStudent;

            ToolTip.Visibility = Visibility.Hidden;
            Table.CurrentCellChanged += TooltipOrTableShow;
        }

        private void TooltipOrTableShow(object sender, EventArgs e)
        {

            if (!is_classEntered)
            {
                int index = Table.CurrentCell.Column.DisplayIndex;
                is_classEntered = true;
                foreach (Class c in classes)
                {
                    if (c.Name.Equals(dataTable.Rows[index][0]))
                    {
                        current_class = new Class(c);
                        //throw new Exception("");
                    }
                }
                TableSet("");
            }
            ToolTip.Visibility = Visibility.Visible;
            //throw new NotImplementedException();
            //ToolTip.Margin = 
        }
        private void TableSet(string pathToFile)
        {


            if (is_start | !is_classEntered)
            {
                XmlDocument? Base = new XmlDocument();
                Base.Load(pathToFile);

                XmlElement? root = Base.DocumentElement;

                if (root == null) return;
                foreach (XmlElement? element in root)
                {
                    switch (element.Name)
                    {
                        case "classes":
                            foreach (XmlNode? node in element.ChildNodes)
                            {
                                int Count = 0;
                                Class c;
                                List<Student> students = new List<Student>();

                                string? Name = node?.Attributes?.GetNamedItem("name")?.Value;

                                foreach (XmlNode? node1 in node?.ChildNodes)
                                {
                                    foreach (XmlNode? node2 in node1?.ChildNodes)
                                    {
                                        Student student = new Student();

                                        foreach (XmlNode node3 in node2?.ChildNodes)
                                        {
                                            switch (node3.Name)
                                            {
                                                case "pluses":
                                                    student.pluses = Int32.Parse(node3.InnerText);
                                                    break;
                                                case "count_of_fives":
                                                    student.countOfFives = Int32.Parse(node3.InnerText);
                                                    break;
                                                case "fio":
                                                    student.FIO = node3.InnerText;
                                                    break;
                                                case "history":
                                                    List<DateTime> history = new List<DateTime>();
                                                    foreach (XmlNode node4 in node3.ChildNodes)
                                                    {
                                                        history.Add(DateTime.Parse(node4.InnerText));
                                                    }
                                                    break;
                                            }
                                        }

                                        students.Add(student);

                                        Count++;
                                    }
                                }

                                c = new Class(Name, students, Count);

                                //throw new Exception("");

                                classes.Add(c);
                            }
                            break;
                        case "user_config":
                            break;
                    }

                }
                dataTable.Columns.Add("Класс", typeof(string));
                dataTable.Columns.Add("Количество учеников", typeof(int));
                foreach (Class c in classes)
                {
                    dataTable.Rows.Add(c.Name, c.Count);
                }
                Table.ItemsSource = dataTable.DefaultView;

                is_start = false;
                return;
            }

            dataTable = new DataTable();


            dataTable.Columns.Add("ФИО", typeof(string));
            dataTable.Columns.Add("Количество плюсов", typeof(int));
            dataTable.Columns.Add("Количество невысталенных пятёрок", typeof(int));

            //throw new NotImplementedException();

            foreach (Student st in current_class.Students)
            {
                dataTable.Rows.Add(st.FIO, st.pluses, st.countOfFives);
            }


            Table.ItemsSource = dataTable.DefaultView;
        }

        private void TableRefresh(string refresher)
        {
            dataTable.Clear();
            if (is_classEntered)
            {
                foreach (Class c in classes)
                {
                    if (c.Name == current_class.Name)
                    {
                        foreach (Student st in c.Students)
                        {
                            if (st.FIO.Contains(refresher))
                            {
                                dataTable.Rows.Add(st.FIO, st.pluses, st.countOfFives);
                            }
                        }
                    }
                }
            }
            else
            {
                foreach (Class c in classes)
                {
                    if (c.Name.Contains(refresher))
                    {
                        dataTable.Rows.Add(c.Name, c.Count);
                    }
                }
            }

            Table.ItemsSource = dataTable.DefaultView;
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            TableRefresh(((TextBox)sender).Text);
        }

        private void Table_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AddStudent(Student student)
        {
            current_class.Students.Add(student);
            for (int i = 0; i < classes.Count; i++)
            {
                if (classes[i].Name == current_class.Name)
                {
                    classes[i] = current_class;
                }
            }
            TableRefresh("");
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Add winadd = new Add();
            winadd.Show();
        }
    }
}
