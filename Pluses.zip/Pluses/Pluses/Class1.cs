﻿using Pluses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Pluses
{
    public class Class
    {
        public string Name { get; set; }
        public List<Student> Students { get; set; } = new List<Student>();

        public int Count { get; set; } = 0;
        public Class(string Name, List<Student> students, int Count)
        {
            this.Name = Name;
            this.Students = students;
            this.Count = Count;
        }

        public Class(Class c)
        {
            this.Name = c.Name;
            this.Students = c.Students;
            this.Count = c.Count;
        }
    }
}
